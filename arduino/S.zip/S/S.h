#ifndef S_h
#define S_h

#include "Arduino.h"

class S
{
  public:
    S(int pin, int pin2, int enabler);
    void up();
    void down();
  private:
    int e;
    int _pin;
    int _pin2;
};

#endif

