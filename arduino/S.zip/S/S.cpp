#include "Arduino.h"
#include "S.h"

S::S(int pin, int pin2, int enabler)
{
  pinMode(pin, OUTPUT);
  pinMode(pin2, OUTPUT);
  pinMode(enbler, OUTPUT);
  e = enabler;
  _pin = pin;
  _pin2 = pin;
}

void S::up()
{
  digitalWrite(e, HIGH);
  digitalWrite(_pin, HIGH);
  digitalWrite(_pin2, LOW);
  delay(10);  
  digitalWrite(e, LOW);
}

void S::down()
{
  digitalWrite(e, HIGH);
  digitalWrite(_pin, LOW);
  digitalWrite(_pin2, HIGH);
  delay(10);  
  digitalWrite(e, LOW);
}

